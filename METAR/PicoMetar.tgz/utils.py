import random
import machine


def shuffle(lst):
    n = len(lst)
    for i in range(n - 1, 0, -1):
        # Generate a random index to swap with
        j = random.randrange(i +
                             1)  # randrange is exclusive of the upper bound
        # Swap lst[i] with lst[j]
        lst[i], lst[j] = lst[j], lst[i]


class WatchDog:

    def __init__(self, ticks=3):
        self._ticks = ticks
        self._reset_value = ticks

    def tick(self):
        if self._ticks <= 0:
            machine.reset()
        self._ticks -= 1

    def feed(self):
        self._ticks = self._reset_value
