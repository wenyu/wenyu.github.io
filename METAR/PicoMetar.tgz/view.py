from config import CONFIG

# Colors are now taken from the CONFIG dictionary
EXPIRATION = 3600
WINDY_DIM = CONFIG['led_windy_dim']

_Category = {
    'VFR': CONFIG['color_vfr'],
    'MVFR': CONFIG['color_mvfr'],
    'IFR': CONFIG['color_ifr'],
    'LIFR': CONFIG['color_lifr'],
}


class AirportView:

    def __init__(self, idx, icao):
        self.idx = idx
        self.icao = icao
        self.updated = 0
        self.status = None

    def update_with(self, statuses, now):
        if self.icao not in statuses:
            return
        self.status = statuses[self.icao]
        self.updated = now

    def getColor(self, now, frame):
        if not self.status or now - self.updated > EXPIRATION:
            return (0, 0, 0)

        result = _Category[self.status['category']]

        if frame:
            if self.status['lightning']:
                return CONFIG['color_lightning']
            if self.status['high_wind']:
                return CONFIG['color_high_wind']
            if self.status['windy']:
                return (int(result[0] * WINDY_DIM), int(result[1] * WINDY_DIM),
                        int(result[2] * WINDY_DIM))
        return result
