import json
import machine
import os

# For debugging


class DummyWDT:
    def __init__(self, timeout):
        pass

    def feed(self):
        pass


CONFIG = {
    'led_pin': 28,
    'led_channel': 'grb',
    'led_brightness': 1,
    'led_night_dim': 0.5,
    'led_windy_dim': 0.15,
    'led_blink_interval': 750,
    'metar_update_interval': 300,
    'latitude': 37.33286,
    'longtitude': -121.81981,
    # Color configurations in RGB order.
    'color_vfr': (0, 255, 0),       # Green
    'color_mvfr': (0, 70, 255),     # Blue
    'color_ifr': (255, 0, 0),       # Red
    'color_lifr': (140, 0, 140),    # Magenta
    'color_lightning': (255, 255, 255),  # White
    'color_high_wind': (255, 255, 0),   # Yellow
}


try:
    with open('config.json') as f:
        CONFIG.update(json.load(f))
except BaseException:
    print('External config load error.')

print('Effective config:', CONFIG)

# Debug mode check
try:
    os.stat('/debug')
    WDT = DummyWDT(8388)
    print('Debug mode, machine WDT disabled.')
except BaseException:
    WDT = machine.WDT(timeout=8388)
