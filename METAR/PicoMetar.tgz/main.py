import os
try:
    os.stat('/debug')
    DEBUG_MODE = True
    print('Debug on')
except BaseException:
    DEBUG_MODE = False

if not DEBUG_MODE:
    import ota
    ota.boot()

if __name__ == '__main__':
    if not DEBUG_MODE:
        ota.startOtaWorker()
    import entry
