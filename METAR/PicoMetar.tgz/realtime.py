import time
import uasyncio as asyncio
from retry import async_retry
from morse import L
from config import CONFIG
from wifi import WiFi
from math import sin, tan, acos, pi, radians, degrees


class _NtpTime:

    def __init__(self):
        self.delta = 0
        self.day_time_range = (0, 1 << 62)
        self.tz_sec = int(CONFIG['longtitude'] * 240)
        print('Effective timezone:', self.tz_sec / 3600)

    async def _update_delta(self):
        print('Updating time.')
        # Use uasyncio.open_connection for non-blocking connect
        reader, writer = await asyncio.open_connection('time.nist.gov', 13)

        # Receive data asynchronously
        r = await reader.read(64)
        if len(r) == 0:
            await asyncio.sleep(1)
            r = await reader.read(64)
        reader.close()
        writer.close()
        await writer.wait_closed()
        await reader.wait_closed()

        if len(r) == 0:
            raise ValueError('NTP returned empty string.')

        chip_time = int(time.time())
        r = r.decode('utf-8').strip()
        r = r.split(' ')
        D = r[1]
        T = r[2]
        y, m, d = [int(x) for x in ('20' + D).split('-')]
        H, M, S = [int(x) for x in T.split(':')]
        now = time.mktime((y, m, d, H, M, S, 0, 0))
        print('Unix epoch:', now)
        print('Delta from chip:', now - chip_time)
        self.delta = now - chip_time
        L('Time OK.')

        # Calculate daylight length
        yday = time.localtime(now)[-1] - 1
        angle_dec = radians(23.44) * sin((yday - 80) * 2 * pi / 365.2422)
        angle_hour = degrees(
            acos(-tan(radians(CONFIG['latitude'])) * tan(angle_dec)))
        day_length = int(480 * angle_hour)  # Seconds
        print(
            f'Daylight length: {day_length // 3600} hours {day_length // 60 % 60} minutes {day_length % 60} seconds.')

        # Calculate daylight time epoch seconds range
        lt = time.localtime(now + self.tz_sec)  # localtime
        local_mid_day = time.mktime(
            (lt[0], lt[1], lt[2], 12, 15, 0, 0, 0)) - self.tz_sec
        day_length >>= 1
        if now >= local_mid_day + day_length:
            local_mid_day += 86400
        self.day_time_range = (
            local_mid_day - day_length,
            local_mid_day + day_length + 1800)
        print(f'Day time epoch range: {self.day_time_range}')

        return self.delta

    def getTimestamp(self):
        return int(time.time()) + self.delta


NtpTime = _NtpTime()


async def ntp_worker():
    while True:
        try:
            while not WiFi.isConnected():
                await asyncio.sleep(1)
            await async_retry(NtpTime._update_delta,
                              N=15,
                              delay=10000,
                              silent_fail=False,
                              gc_on_failure=True)
            await asyncio.sleep(3600 * 4)
        except BaseException:
            L('No time.')
            await asyncio.sleep(30)


def startNtpWorker():
    asyncio.create_task(ntp_worker())
