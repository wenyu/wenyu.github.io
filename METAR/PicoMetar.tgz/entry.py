from view import AirportView
from realtime import startNtpWorker, NtpTime
from wifi import WiFi, startWifiGuard
import leds
import uasyncio as asyncio
import machine
from morse import L
import time
import gc
from metar import METAR
from utils import shuffle, WatchDog
from config import CONFIG, WDT

gc.enable()

WATCH_DOG = WatchDog(ticks=15)

# Start LEDs
with open('airports.txt') as f:
    airports = f.read().strip().split('\n')
print(f'Total {len(airports)} LEDs: {airports}')


LEDs = leds.LEDs(len(airports), pin=CONFIG['led_pin'])
LEDs.startRainbowAnimation()

airport_views = [
    AirportView(idx, icao) for idx, icao in enumerate(airports) if icao
]


async def view_worker():
    while LEDs.rainbow_running:
        await asyncio.sleep(1)
    await asyncio.sleep_ms(500)

    frame = False
    night_dim = CONFIG['led_night_dim']
    blink_interval = CONFIG['led_blink_interval']

    while True:
        now = NtpTime.getTimestamp()
        if now > NtpTime.day_time_range[0] and now < NtpTime.day_time_range[1]:
            LEDs.brightness = 1.0
        else:
            LEDs.brightness = night_dim

        frame = not frame
        t = int(time.time())
        for av in airport_views:
            LEDs.L[av.idx] = av.getColor(t, frame)

        LEDs.write()
        await asyncio.sleep_ms(blink_interval)


asyncio.create_task(view_worker())


async def update_metar(group_size=10):
    update_interval = CONFIG['metar_update_interval']
    aps = [icao for icao in airports if icao]
    empty_retry = 2
    while True:
        if not WiFi.isConnected():
            await asyncio.sleep(5)
            continue

        updated = 0
        shuffle(aps)
        for i in range(0, len(aps), group_size):
            t = int(time.time())
            gc.collect()
            status = await METAR(*aps[i:i + group_size], hoursBeforeNow=2)
            for v in airport_views:
                v.update_with(status, t)
            updated += len(status)
            if updated:
                LEDs.stopRainbowAnimation()

        gc.collect()
        if updated == 0:
            L('No METAR.')
            empty_retry -= 1
            if empty_retry <= 0:
                L('Reset WiFi.')
                WiFi.deactivate()
            await asyncio.sleep(5)
            continue

        empty_retry = 2
        WATCH_DOG.feed()
        L('METAR updated.')
        await asyncio.sleep(update_interval)


async def main():
    # Wait until WiFi ready and time is fetched.
    startWifiGuard()
    watch_dog = WatchDog(ticks=120)
    while not WiFi.isConnected():
        await asyncio.sleep(1)
        watch_dog.tick()

    startNtpWorker()
    asyncio.create_task(update_metar())

    while True:
        await asyncio.sleep(60)
        WATCH_DOG.tick()


asyncio.run(main())
