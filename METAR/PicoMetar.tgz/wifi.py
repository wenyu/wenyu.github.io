from morse import L
import uasyncio as asyncio
from utils import shuffle
import gc

import network
import json

with open('wifi.json') as f:
    _networks = json.load(f)
    print('WiFi networks:', _networks)


class _WiFi:

    def __init__(self):
        print('WiFi Initializing')
        self.w = network.WLAN(network.STA_IF)
        self.last = None
        self.guarded = False

    def isConnected(self):
        return self.w.isconnected()

    def deactivate(self):
        self.w.disconnect()
        self.last = None
        self.w.active(False)

    async def forceCycle(self):
        L('WiFi force cycle.')
        self.deactivate()
        await asyncio.sleep(5)
        await self.connect()

    async def tryConnect(self, ssid, psk):
        for _ in range(3):
            t = 5
            self.w.connect(ssid, psk)
            while t > 0:
                t -= 1
                await asyncio.sleep(1)
                if self.isConnected():
                    L('WiFi up.')
                    self.last = (ssid, psk)
                    return True
        return self.isConnected()

    async def connect(self):
        if not self.isConnected():
            self.w.active(True)
            if self.last:
                L('WiFi retry.')
                if await self.tryConnect(*self.last):
                    return True

            retries = 5
            while retries > 0:
                retries -= 1
                L('WiFi scan.')
                gc.collect()
                scan_result = self.w.scan()
                # scan_result.sort(key=lambda v: v[3], reverse=True)
                attempt_order = [ap for ap in scan_result if ap[3] >= -75]
                shuffle(attempt_order)
                attempt_order.extend([ap for ap in scan_result if ap[3] < -75])
                print(attempt_order)

                for n in attempt_order:
                    ssid = n[0].decode('utf-8')
                    if ssid not in _networks:
                        continue

                    print(f'WiFi try: {ssid}')
                    if await self.tryConnect(ssid, _networks[ssid]):
                        return True

                    await asyncio.sleep(2)

                await asyncio.sleep(5)

            L('WiFi down.')
            return False
        return True

    async def guard_worker(self):
        if self.guarded:
            print('WiFi guard is already running.')
            return
        self.guarded = True
        print('WiFi guard started.')
        while self.guarded:
            if self.isConnected():
                await asyncio.sleep(10)
                continue

            print('WiFi is down.')
            if not await self.connect():
                await self.forceCycle()
            await asyncio.sleep(60)


WiFi = _WiFi()


def startWifiGuard():
    asyncio.create_task(WiFi.guard_worker())
