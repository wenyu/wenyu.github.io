import uasyncio as asyncio
import gc


class Response:
    def __init__(self, status, reason, headers, reader, writer):
        self.status_code = status
        self.reason = reason
        self.headers = headers
        self._reader = reader
        self._writer = writer
        self._cache = None
        self._closed = reader is None

    @property
    def reader(self):
        if self._closed:
            return None
        return self._reader

    @property
    def writer(self):
        if self._closed:
            return None
        return self._writer

    async def get_content(self, max_read=12288):
        if self._cache is None:
            self._cache = await self.reader.read(max_read)
            self.close()
        return self._cache

    @property
    def text(self):
        return self._cache.decode()

    def is_closed(self):
        return self._closed

    def close(self):
        self._closed = True
        if self._reader:
            self._reader.close()
        if self._writer:
            self._writer.close()

    async def wait_closed(self):
        if self._reader:
            await self._reader.wait_closed()
        if self._writer:
            await self._writer.wait_closed()

    def __del__(self):
        self.close()

    def __repr__(self):
        if self._cache is None:
            return f'<Response location={hex(id(self))} status={self.status_code} closed={self.is_closed()}>'
        return f'<Response location={hex(id(self))} status={self.status_code} closed={self.is_closed()} cache_size={len(self._cache)} >'


async def request(method, url, headers={}, timeout=5, auth=None, parse_headers=False, max_redirects=20, fetch_now=True):
    def attempt(coro):
        return asyncio.wait_for(coro, timeout)

    if auth is not None:
        import ubinascii

        username, password = auth
        formated = b'{}:{}'.format(username, password)
        formated = str(ubinascii.b2a_base64(formated)[:-1], 'ascii')
        headers['Authorization'] = 'Basic {}'.format(formated)

    while url and max_redirects > 0:
        if max_redirects < 0:
            raise ValueError('HTTP error: too many redirects.')
        max_redirects -= 1
        try:
            proto, _, host, path = url.split('/', 3)
        except ValueError:
            proto, _, host = url.split('/', 2)
            path = ''

        if proto == 'http:':
            ssl = None
            port = 80
        elif proto == 'https:':
            ssl = True
            port = 443
        else:
            raise ValueError('Unsupported protocol: ' + proto)

        if ':' in host:
            host, port = host.split(':', 1)
            port = int(port)

        url = None
        gc.collect()

        reader, writer = await attempt(asyncio.open_connection(host, port, ssl))
        force_close_streams = False

        try:
            writer.write(b'%s /%s HTTP/1.0\r\n' % (method, path))
            writer.write(b'Host: %s\r\n' % host)
            for k, v in headers.items():
                writer.write(k)
                writer.write(b': ')
                writer.write(v)
                writer.write(b'\r\n')
                await attempt(writer.drain())
            writer.write(b'Connection: close\r\n\r\n')
            await attempt(writer.drain())

            l = await attempt(reader.readline())
            l = l.split(None, 2)
            assert len(l) >= 2
            status = int(l[1])
            reason = ''
            if len(l) > 2:
                reason = l[2]
            resp_h = {}

            while True:
                l = await attempt(reader.readline())
                if l == b'\r\n':
                    break
                k, v = l.decode().rstrip('\r\n').split(': ', 1)
                k = k.lower()

                if status in [301, 302, 303, 307, 308]:
                    if k == 'location':
                        url = v
                        force_close_streams = True
                        break
                elif status >= 400:
                    force_close_streams = True
                    break

                if parse_headers or k in ['content-length', 'content-type']:
                    resp_h[k] = v

        finally:
            if force_close_streams:
                reader.close()
                writer.close()
                await reader.wait_closed()
                await writer.wait_closed()
                reader = None
                writer = None
            gc.collect()

    resp = Response(status, reason, resp_h, reader, writer)
    if not reader:
        resp._cache = b''
    if fetch_now:
        await attempt(resp.get_content())
    return resp


def get(*args, **kwargs):
    return request('GET', *args, **kwargs)
