from machine import Pin
import neopixel
import uasyncio as asyncio
from config import CONFIG, WDT
import utils

MAX_BRIGHTNESS = CONFIG['led_brightness']
CHANNEL_R, CHANNEL_G, CHANNEL_B = (CONFIG['led_channel'].index('r'),
                                   CONFIG['led_channel'].index('g'),
                                   CONFIG['led_channel'].index('b'))


class LEDs:

    def __init__(self, N, pin=0):
        self.pin = Pin(pin, Pin.OUT)
        self.N = N
        self._leds = neopixel.NeoPixel(self.pin, self.N)
        self.L = [(0, 0, 0) for _ in range(N)]
        self.brightness = 1.0
        self.rainbow_task = None
        self.rainbow_running = False

    def _getWheelColor(self, pos):
        if pos < 0 or pos > 255:
            r = g = b = 0
        elif pos < 85:
            r = int(pos * 3)
            g = int(255 - pos * 3)
            b = 0
        elif pos < 170:
            pos -= 85
            r = int(255 - pos * 3)
            g = 0
            b = int(pos * 3)
        else:
            pos -= 170
            r = 0
            g = int(pos * 3)
            b = int(255 - pos * 3)
        return (r, g, b)

    def _setRainbowWheel(self, phase):
        for i in range(self.N):
            c = ((i << 8) // self.N + phase) & 0xFF
            self.L[i] = self._getWheelColor(c)
        self.write()

    def write(self):
        if self.brightness < 0.0:
            self.brightness = 0.0
        elif self.brightness > 1.0:
            self.brightness = 1.0
        for i in range(self.N):
            self._leds[i] = (int(self.L[i][CHANNEL_R] * self.brightness *
                                 MAX_BRIGHTNESS),
                             int(self.L[i][CHANNEL_G] * self.brightness *
                                 MAX_BRIGHTNESS),
                             int(self.L[i][CHANNEL_B] * self.brightness *
                                 MAX_BRIGHTNESS))
        self._leds.write()
        WDT.feed()

    def turnOffLeds(self):
        self.brightness = 0.0
        for i in range(self.N):
            self.L[i] = (0, 0, 0)
        self.write()

    def setAll(self, color, brightness):
        color = tuple([int(x * brightness) for x in color])
        for i in range(self.N):
            self.L[i] = color
        self.write()

    async def _ledCheck(self):
        colors = sorted([
            tuple(v) for k, v in CONFIG.items() if k.startswith('color_')
        ])
        brightness = sorted([
            d1 * d2
            for d1 in [1.0, CONFIG['led_night_dim']] for d2 in [1.0, CONFIG['led_windy_dim']]
        ], reverse=True)

        for c in colors:
            for b in brightness:
                self.setAll(c, b)
                await asyncio.sleep_ms(200)

        i = 0
        while i < self.N:
            for c in colors:
                for b in brightness:
                    if i < self.N:
                        self.L[i] = tuple([int(x * b) for x in c])
                        i += 1
                    else:
                        break

        for i in range(3):
            self.write()
            await asyncio.sleep_ms(1000)
            utils.shuffle(self.L)

    async def _rainbowAnimation(self):
        self.rainbow_running = True
        try:
            await self._ledCheck()
            if self.rainbow_task:
                self.brightness = 0.0
            i = 0
            while self.rainbow_task:
                if self.brightness < 1.0:
                    self.brightness += 0.1
                self._setRainbowWheel(i)
                i = (i + 15) & 0xFF
                await asyncio.sleep_ms(100)
        finally:
            n = 30
            while self.brightness > 0.0 and n > 0:
                self.brightness -= 0.1
                n -= 1
                self._setRainbowWheel(i)
                i = (i + 15) & 0xFF
                await asyncio.sleep_ms(100)
            self.turnOffLeds()
            self.rainbow_running = False

    def startRainbowAnimation(self):
        if self.rainbow_task:
            return
        print('Starting rainbow.')
        self.rainbow_task = asyncio.create_task(self._rainbowAnimation())

    def stopRainbowAnimation(self):
        task = self.rainbow_task
        if not task:
            return
        self.rainbow_task = None
        print('Stopping rainbow.')
