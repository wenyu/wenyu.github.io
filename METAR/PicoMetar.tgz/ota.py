import os
import sys
import uasyncio as asyncio
import gc
try:
    from morse import L
except BaseException:
    def L(x):
        print(x)

try:
    with open('alter_ota') as f:
        OTA_INFO_URL = f.read().strip()
    print('Using alternative OTA URL:', OTA_INFO_URL)
except BaseException:
    OTA_INFO_URL = 'https://wenyu.github.io/METAR/PicoMetarVersion.txt'

OTA_FILE = 'ota.tgz'
OTA_INFO_FILE = 'ota_info'
OTA_CHECKSUM = ''
OTA_URL = ''
HAVE_OTA_FILE = False

CURRENT_CHECKSUM_FILE = 'checksum'
CURRENT_CHECKSUM = ''
CRITICAL_FILES = [
    'main.py',
    'http.py',
    'ota.py',
    'wifi.py',
    'retry.py',
    'morse.py']


def _crc32_table():
    polynomial = 0xEDB88320
    table = []
    for i in range(256):
        crc = i
        for _ in range(8):
            if crc & 1:
                crc = (crc >> 1) ^ polynomial
            else:
                crc = crc >> 1
        table.append(crc)
    return table


def crc32(f):
    table = _crc32_table()
    crc = 0xFFFFFFFF

    while True:
        data = f.read(512)
        if not data:
            break
        for b in data:
            crc = table[(crc ^ b) & 0xFF] ^ (crc >> 8)

    data = None
    gc.collect()
    result = '%08x' % (~crc & 0xFFFFFFFF)
    print('Checksum:', result)
    return result


def unpack_single(f):
    header = f.read(512)
    if not header or len(header) < 512:
        raise EOFError()
    name = header[:100].strip(b'\0').decode()
    if not name:
        return None
    update_name = name
    if name in CRITICAL_FILES:
        update_name = '_' + name
    size_str = header[124:136]
    size = int(size_str, 8)
    remain = size

    with open(update_name, 'wb') as o:
        while remain > 0:
            content = f.read(512)
            if remain < 512:
                content = content[:remain]
            o.write(content)
            remain -= 512

    return name


def unpack_tar(f):
    existing = [x for x in os.listdir() if x.endswith('.py')]
    unpacked = []

    while True:
        last_file = unpack_single(f)
        gc.collect()
        if last_file:
            unpacked.append(last_file)
        else:
            break
    print('Unpack complete.')

    for c in CRITICAL_FILES:
        if c in unpacked:
            os.rename('_' + c, c)
    print('Updated critical files.')
    gc.collect()

    for e in existing:
        if e not in unpacked:
            os.remove(e)
    print('Deleted obsolete files.')
    gc.collect()


async def delayed_restart():
    for i in range(10, 0, -1):
        print('Restarting in', i)
        await asyncio.sleep(1)
    import machine
    machine.reset()


def apply_update():
    L('OTA updating now.')
    try:
        import deflate
        gc.collect()
        with open(OTA_FILE, 'rb') as f:
            crc = crc32(f)
            if CURRENT_CHECKSUM and CURRENT_CHECKSUM == crc:
                return

            if (OTA_CHECKSUM and OTA_CHECKSUM != crc) and CURRENT_CHECKSUM:
                os.remove(OTA_FILE)
                return

            f.seek(0)
            with deflate.DeflateIO(f, deflate.GZIP) as zf:
                unpack_tar(zf)

        with open(CURRENT_CHECKSUM_FILE, 'w') as f:
            f.write(crc)

        print('Update successful.')

    except Exception as e:
        print('Update failed:')
        sys.print_exception(e)

    finally:
        os.sync()
        asyncio.run(delayed_restart())


def check_update_readiness():
    global CURRENT_CHECKSUM
    global HAVE_OTA_FILE
    global OTA_CHECKSUM
    global OTA_URL

    try:
        with open(CURRENT_CHECKSUM_FILE) as f:
            CURRENT_CHECKSUM = f.read().strip()
    except BaseException:
        CURRENT_CHECKSUM = ''

    try:
        with open(OTA_INFO_FILE) as f:
            OTA_CHECKSUM, OTA_URL = f.read().strip().split('\n', 1)
    except BaseException:
        OTA_CHECKSUM, OTA_URL = '', ''

    try:
        os.stat(OTA_FILE)
        HAVE_OTA_FILE = True
    except BaseException:
        HAVE_OTA_FILE = False

    print(
        f'OTA readiness: {CURRENT_CHECKSUM}, {OTA_CHECKSUM}, {OTA_URL}, {HAVE_OTA_FILE}')


def should_update_now():
    if not CURRENT_CHECKSUM:
        return HAVE_OTA_FILE
    else:
        if OTA_CHECKSUM:
            return OTA_CHECKSUM != CURRENT_CHECKSUM and HAVE_OTA_FILE
    return False


def boot():
    check_update_readiness()
    if should_update_now():
        apply_update()


async def get_ota_info():
    from wifi import WiFi, startWifiGuard
    if not WiFi.guarded:
        startWifiGuard()
    while not WiFi.isConnected():
        await asyncio.sleep(1)

    from http import get
    from retry import async_retry
    resp = await async_retry(get, (OTA_INFO_URL,), silent_fail=False, gc_on_failure=True)
    assert resp.status_code == 200
    return resp.text


async def download(url, target):
    from wifi import WiFi, startWifiGuard
    if not WiFi.guarded:
        startWifiGuard()
    while not WiFi.isConnected():
        await asyncio.sleep(1)

    from http import get
    from retry import async_retry
    print(f'Getting {url} to {target}')
    try:
        resp = await async_retry(get, (url,), {'fetch_now': False}, silent_fail=False, gc_on_failure=True)
        downloaded = 0
        with open(target, 'wb') as f:
            while downloaded <= 32768:
                data = await resp.reader.read(1024)
                if not data:
                    break
                f.write(data)
                downloaded += len(data)
                print(f'Downloaded {downloaded} bytes.')
        if downloaded > 32768:
            os.remove(target)
            raise ValueError('The OTA package is unusally large, aborting.')
    finally:
        resp.close()
        await resp.wait_closed()
        os.sync()


async def download_ota_package():
    if OTA_CHECKSUM != CURRENT_CHECKSUM and OTA_URL:
        if HAVE_OTA_FILE:
            with open(OTA_FILE, 'rb') as f:
                crc = crc32(f)
            if crc == OTA_CHECKSUM:
                return

        await download(OTA_URL, OTA_FILE)
        with open(OTA_FILE, 'rb') as f:
            crc = crc32(f)
        if crc != OTA_CHECKSUM:
            os.remove(OTA_FILE)
            raise ValueError('OTA package checksum does not match.')


def is_valid_crc(s):
    import re
    return bool(re.match(r'^' + '[0-9a-f]' * 8 + '$', s))


async def prepare_ota():
    try:
        check_update_readiness()
        info = await get_ota_info()
        checksum, url = info.strip().split('\n', 1)
        if '\n' in url:
            url, _ = url.strip().split('\n', 1)
        print('OTA Info:', checksum, url)
        if not is_valid_crc(checksum):
            raise ValueError('Invalid CRC.')
        if not url.startswith('http://') and not url.startswith('https://'):
            raise ValueError('Invalid OTA Package URL.')
        if checksum == CURRENT_CHECKSUM:
            print('OTA checksum is identical.')
            return False
        with open(OTA_INFO_FILE, 'w') as f:
            f.write(checksum)
            f.write('\n')
            f.write(url)
        check_update_readiness()
        await download_ota_package()
        check_update_readiness()
        if should_update_now():
            print('OTA is ready.')
            await delayed_restart()
            return True

    except (OSError, ValueError) as e:
        print('OTA not available:', e)
        sys.print_exception(e)

    except Exception as e:
        print('Failed preparing OTA.')
        sys.print_exception(e)

    return False


async def ota_worker():
    from wifi import WiFi
    while not WiFi.isConnected():
        await asyncio.sleep(1)
    await asyncio.sleep(10)
    while True:
        while not WiFi.isConnected():
            await asyncio.sleep(1)

        await prepare_ota()
        await asyncio.sleep(3600)


def startOtaWorker():
    asyncio.create_task(ota_worker())


if __name__ == '__main__':
    boot()
