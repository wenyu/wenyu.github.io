import uasyncio as asyncio
import gc


def retry(func,
          args=(),
          kwargs={},
          N=3,
          silent_fail=True,
          gc_on_failure=False):
    while N > 0:
        N -= 1
        try:
            result = func(*args, **kwargs)
            return result
        except Exception as e:
            if gc_on_failure:
                gc.collect()
            print('Retry left', N, 'on', args, kwargs, 'with error:', e)
            last_e = e
    if silent_fail:
        return None
    raise last_e


async def async_retry(func,
                      args=(),
                      kwargs={},
                      N=5,
                      delay=500,
                      silent_fail=True,
                      gc_on_failure=False):
    while N > 0:
        N -= 1
        try:
            result = await func(*args, **kwargs)
            return result
        except Exception as e:
            if gc_on_failure:
                gc.collect()
            print('Retry left', N, 'on', args, kwargs, 'with error:', e)
            last_e = e
            await asyncio.sleep_ms(delay)
    if silent_fail:
        return None
    raise last_e


async def async_retry_sync_func(func,
                                args=(),
                                kwargs={},
                                N=5,
                                delay=500,
                                silent_fail=True,
                                gc_on_failure=False):
    while N > 0:
        N -= 1
        try:
            result = func(*args, **kwargs)
            return result
        except Exception as e:
            if gc_on_failure:
                gc.collect()
            print('Retry left', N, 'on', args, kwargs, 'with error:', e)
            last_e = e
            await asyncio.sleep_ms(delay)
    if silent_fail:
        return None
    raise last_e
