from retry import async_retry
import http as requests
import gc
import time

ENDPOINT = 'https://aviationweather.gov/cgi-bin/data/dataserver.php'
WINDY = 15
HIGH_WIND = 25


async def http_get(url):
    print(f'Requesting URL:', url)
    stop_watch = time.time()
    resp = await async_retry(requests.get, (url, ), {'timeout': 5, 'fetch_now': False},
                             N=3,
                             delay=1100,
                             silent_fail=False,
                             gc_on_failure=True)
    code = resp.status_code
    if code != 200:
        resp.close()
        await resp.wait_closed()
        raise ValueError('HTTP request error:', code)
    return resp


def _buildUrl(*args, **kwargs):
    params = {
        'requestType': 'retrieve',
        'format': 'csv',
    }
    params.update(kwargs)
    get_params = '&'.join([f'{k}={v}' for k, v in params.items()])
    return f'{ENDPOINT}?{get_params}'


async def _basicRequest(*args, **kwargs):
    print(
        f'Memory pressure before request: {gc.mem_alloc()} used, {gc.mem_free()} free.'
    )
    url = _buildUrl(*args, **kwargs)
    resp = await http_get(url)
    try:
        reader = resp.reader
        headers = []
        for _ in range(6):
            headers.append((await reader.readline()).decode().strip())
        assert headers[0] == 'No errors'
        fieldnames = headers[5].split(',')
        result = []
        while True:
            row = (await reader.readline()).decode().strip()
            if not row:
                break
            result.append(dict(zip(fieldnames, row.split(','))))
        return result
    finally:
        resp.close()
        await resp.wait_closed()
        gc.collect()
        print(
            f'Memory pressure after request: {gc.mem_alloc()} used, {gc.mem_free()} free.'
        )


def _groupby(iterable, keyfunc=None):
    if keyfunc is None:
        def keyfunc(x): return x

    groups = {}
    for item in iterable:
        key = keyfunc(item)
        if key in groups:
            groups[key].append(item)
        else:
            groups[key] = [item]

    yield from groups.items()


def _mostRecentSelector(key):
    return lambda l: max(l, key=lambda o: o[key])


def _groupByStation(l, mostRecent=None):
    selector = _mostRecentSelector(mostRecent) if mostRecent else list
    return dict(
        map(lambda x: (x[0], selector(x[1])),
            _groupby(l, lambda x: x['station_id'])))


def FlightCategory(w, preferGiven=True):
    fc = w['flight_category'].upper()
    if fc not in ['VFR', 'MVFR', 'IFR', 'LIFR']:
        fc = ''
    if fc and preferGiven:
        return fc

    vis = float('0' + w['visibility_statute_mi'])
    ceil = int('0' + w['cloud_base_ft_agl'])
    if not ceil:
        ceil = 1000000
        for _, base in re.findall(r'\s(BKN|OVC|VV)(\d+)', w['raw_text']):
            ceil = min(ceil, int(base) * 100)

    if vis < 1.0 or ceil < 500:
        return 'LIFR'
    if vis < 3.0 or ceil < 1000:
        return 'IFR'
    if vis <= 5.0 or ceil <= 3000:
        return 'MVFR'
    return 'VFR'


def _int(s):
    try:
        return int(s)
    except BaseException:
        return 0


def FlightInfo(w):
    windSpeed = _int(w.get('wind_speed_kt'))
    windGust = _int(w.get('wind_gust_kt'))
    wind = max(windSpeed, windGust)
    raw = w.get('raw_text', '')[4:]
    lightning = any(map(lambda x: x in raw, ['LTG', 'TS', 'TSNO']))
    result = {
        'category': FlightCategory(w),
        'windy': wind > WINDY,
        'high_wind': wind > HIGH_WIND,
        'lightning': lightning,
    }
    return result


async def METAR(*args, hoursBeforeNow=3, mostRecent=True, **kwargs):
    print('Updating METAR for:', *args)
    result = {}
    try:
        resp = await _basicRequest(stationString=','.join(args),
                                   dataSource='metars',
                                   hoursBeforeNow=hoursBeforeNow,
                                   mostRecentForEachStation=str(mostRecent).lower())
        metars = _groupByStation(resp,
                                 'observation_time' if mostRecent else None)
        for k, v in metars.items():
            result[k] = FlightInfo(v)
        print(result)
    except Exception as e:
        print('METAR update failed:', e)
    finally:
        gc.collect()
    return result
