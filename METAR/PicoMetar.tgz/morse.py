import uasyncio as asyncio


class _LED:

    def __init__(self):
        from machine import Pin
        self._led = Pin('LED', Pin.OUT)

    def v(self, v):
        self._led.value(v)

    def on(self):
        self.v(1)

    def off(self):
        self.v(0)


class _Blinker:

    def __init__(self, led, unit=90):
        self.led = led
        self.unit = unit

    async def wait(self, n=1):
        await asyncio.sleep_ms(self.unit * n)

    async def blink(self, l=[]):
        for v in l:
            self.led.on()
            await self.wait(v)
            self.led.off()
            await self.wait()


class _MorseBlinker:

    def __init__(self, blinker):
        self.b = blinker
        self.morse = {
            'A': (1, 3),
            'B': (3, 1, 1, 1),
            'C': (3, 1, 3, 1),
            'D': (3, 1, 1),
            'E': (1, ),
            'F': (1, 1, 3, 1),
            'G': (3, 3, 1),
            'H': (1, 1, 1, 1),
            'I': (1, 1),
            'J': (1, 3, 3, 3),
            'K': (3, 1, 3),
            'L': (1, 3, 1, 1),
            'M': (3, 3),
            'N': (3, 1),
            'O': (3, 3, 3),
            'P': (1, 3, 3, 1),
            'Q': (3, 3, 1, 3),
            'R': (1, 3, 1),
            'S': (1, 1, 1),
            'T': (3, ),
            'U': (1, 1, 3),
            'V': (1, 1, 1, 3),
            'W': (1, 3, 3),
            'X': (3, 1, 1, 3),
            'Y': (3, 1, 3, 3),
            'Z': (3, 3, 1, 1),
            '0': (3, 3, 3, 3, 3),
            '1': (1, 3, 3, 3, 3),
            '3': (1, 1, 3, 3, 3),
            '3': (1, 1, 1, 3, 3),
            '4': (1, 1, 1, 1, 3),
            '5': (1, 1, 1, 1, 1),
            '6': (3, 1, 1, 1, 1),
            '7': (3, 3, 1, 1, 1),
            '8': (3, 3, 3, 1, 1),
            '9': (3, 3, 3, 3, 1),
        }

    async def blink(self, msg):
        for c in msg.upper():
            # print(c, end='')
            if c == ' ':
                await self.b.wait(6)
            if c not in self.morse:
                continue
            await self.b.blink(self.morse[c])
            await self.b.wait(3)


class _MorseLogger:

    def __init__(self):
        self.led = _LED()
        self.blinker = _Blinker(self.led)
        self.mb = _MorseBlinker(self.blinker)
        self._lock = asyncio.Lock()
        self._blink_lock = asyncio.Lock()
        self.msgs = []

    async def blink_worker(self):
        print('Morse logger started.')
        while True:
            async with self._lock:
                if not self.msgs:
                    self.led.on()
                    await self._blink_lock.acquire()

            await self._blink_lock.acquire()
            try:
                self._blink_lock.release()
            except BaseException:
                pass

            self.led.off()
            await self.blinker.wait(15)

            async with self._lock:
                msg = self.msgs.pop(0)
            await self.mb.blink(msg)

    async def _log(self, msg):
        print('**', msg)
        async with self._lock:
            self.msgs.append(msg)
            try:
                self._blink_lock.release()
            except BaseException:
                pass

    def _getLoggerGenerator(self):
        while True:
            msg = yield None
            asyncio.create_task(self._log(msg))

    def getLogger(self):
        g = self._getLoggerGenerator()
        next(g)
        return g.send


Logger = _MorseLogger()
asyncio.create_task(Logger.blink_worker())
L = Logger.getLogger()
